<?php
  //Esta classe irá estender a classe PDO do PHP - a classe PDO faz a interação do Back x Banco, possibilitando acessar os dados - fazer o CRUD.
  class ConexaoBanco extends PDO {
    //Atributo para instanciar - criar uma conexão:
    private static $instance = null;
    //Método construtor:
    public function __construct($dsn,$user,$pass){
      //O construtor ele vem da classe PAI - da classe PDO:
      parent::__construct($dsn,$user,$pass);
    }
    //Método para pegar a instancia para conectar com banco:
    public static function getInstance(){
      //Verificamos se não existe uma conexão com bd ativa - se ! NÃO existir - ele conecta:
      if(!isset(self::$instance)){
        try{ //tratando excessoes de erro
          //Crie e retorna a conexão com o Banco
          self::$instance = new ConexaoBanco("mysql:dbname=id16259186_bdcadastro;host=localhost","id16259186_user","V76yq2C4hh%52n}%");
        }catch(PDOException $e){
          echo "Erro ao conectar. ".$e;
        }//fecha excessao
      }//fecha o if
      return self::$instance;
    }//fecha o método de instancia
  }
