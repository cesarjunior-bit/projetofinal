<?php
  class Cadastro{
    //Atributos - características:
    //Acrescentar para facilitar a manipulação
    private $idcadastro;
    private $email;
    private $senha;
    private $nome;
    private $site;
    //Funções - ações da classe:
    //Função construir o objeto - instanciar
    public function __construct(){
      /*$this->nome = $nome;
      $this->telefone = $telefone;
      $this->email = $email;
      $this->mensagem = $mensagem;*/
    }
    //Gets e Sets - mágicos:
    public function __get($atributo){
      return $this->$atributo;
    }
    public function __set($atributo,$valor){
      $this->$atributo = $valor;
    }
    //Função toString:
    public function __toString(){
      return "<br>Id Cadastro: ".$this->idcadastro.
             "<br>email: ".$this->email.
             "<br>senha: ".$this->senha.
             "<br>nome: ".$this->nome.
             "<br>site: ".$this->site;
    }
}

?>
