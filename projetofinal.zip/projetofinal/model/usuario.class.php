<?php
class Usuario {

  private $idUsuario;
  private $login;
  private $senha;
  private $tipo;

  public function __construct(){}
  public function __destruct(){}

    //Gets e Sets - mágicos:
    public function __get($atributo){
      return $this->$atributo;
    }
    public function __set($atributo,$valor){
      $this->$atributo = $valor;
    }

   public function __toString(){
    return "<br>Login:" .$this->login.
            "<br>Senha: " .$this->senha.
            "<br>Tipo: " .$this->tipo;
  }//fecha toString

}//fecha classe
