<?php
//Colocamos aqui start sessão:
session_start();
include '../model/cadastro.class.php';
include '../util/util.class.php';
//Incluimos a classe que possui o CRUD:
include '../dao/cadastrodao.class.php';

//Instanciar a classe util para validar:
$u1 = new Util();
switch ($_GET['op']) {
  case 'cadastrar':
    //Pegando os dados do form:
    $email = $_POST['txtemail'];
    $senha = $_POST['txtsenha'];
    $nome = $_POST['txtnome'];
    $site = $_POST['txtsite'];
    //validaçao e instancia:
    $erro = '';
    //Validando e verificando formatos expressões:
    if (empty($email) || empty($senha) || empty($site)) {
      $erro = 'Preencha os dados.';
    } else if (!$u1->validarEmail($email)) {
      $erro = 'email fora do padrão';
    } else if (!$u1->testarExpressaoRegular('/^[A-Za-zÀ-Úà-ú ]{2,30}$/', $nome)) {
      $erro = 'nome fora do padrão';
    } else if (!$u1->testarExpressaoRegular('/^[A-Za-zÀ-Úà-ú ]{2,30}$/', $site)) {
      $erro = 'site fora do padrão';
    } else {
      $c1 = new Cadastro();
      //Enviando os dados para o objeto:
      $c1->email = $email;
      $c1->senha = $senha;
      $c1->nome = $nome;
      $c1->site = $site;
      //Verificando o cadastro em contato.class.php
      echo $c1;
      echo "<hr><br>";
      //var_dump($c1);

      //Aqui enviamos para o BANCO:
      $cadastroDAO = new CadastroDAO();
      $cadastroDAO->cadastrarCadastro($c1);
      header('location:../view/confirmacadastro.html');
    } //fecha else do cadastro.
    //Depois para tela de erro separada:
    if (!empty($erro)) {
      $_SESSION['cadastros'] = serialize($erro);
      header('location:../view/mensagemerro.php');
    }
    break;

  case 'deletar':
    //instancia a classe contatoDAO para acessar a função de excluir:
    $cDAO = new CadastroDAO();
    //acessa a função - mandando o idcontato - que será requerido quando a pessoa pedir para remover contato:
    $cDAO->deletarCadastro($_REQUEST['idcadastro']);
    //aqui redireciona para a página buscarcontatos de volta:
    header('location:../view/buscarcadastro.php');
    break; //fecha case deletar

    //Este case é como se fosse o pedido de alteração, ele verifica com o idcontato - procurando o contato desejado para alteração:
    //pede idcontato porque precisa por na pesquisa:
  case 'alterar':
    //pega pela barra de endereço o id, poderia ser por REQUEST tbm
    $idcadastro = $_GET['idcadastro'];
    //monta a query para enviar para buscar:
    $query = 'where idcadastro = ' . $idcadastro;
    //cria objeto DAO para acessar os métodos:
    $cDAO = new CadastroDAO();
    //cria uma variável para guardar o que encontrar na pesquisa - objeto - então coloca em array:
    $cadastros = array();
    //atribui a busca na variável criada:
    $cadastros = $cDAO->buscar($query);
    //Inicia uma sessão para passar à outra página o resultado da busca:
    //Função serialize possibilita buscar uma string de resposta:
    $_SESSION['dados_cadastro'] = serialize($cadastros);
    //direciona para uma página de alterarContato - igual cadastra - porém preenchida:
    header("location:../view/alterarcadastro.php");

    break;

    //Aqui iremos confirmar a alteração - ou seja fazer realmente a alteração:
  case 'confirmaralteracao':
    //instanciamos um contato:
    $c = new Cadastro();

    //pegamos os dados do form
    $c->idcadastro = $_POST['idcadastro'];
    $c->email = $_POST['txtemail'];
    $c->senha = $_POST['txtsenha'];
    $c->nome = $_POST['nome'];
    $c->site = $_POST['site'];
    /* Enviando objeto $c para o banco de dados */
    $cDAO = new CadastroDAO();
    //Enviando para o método alterarSorvete
    $resultado = $cDAO->alterarCadastro($c);

    if ($resultado) {
      //direciona para a busca:
      header("location:../view/buscarcadastro.php");
    } else {
      echo "Deu errado";
    }


    break;

    //qualquer outro caso - erro
  default:

    echo 'Aff! Errou!';

    break;
}//fecha switch
