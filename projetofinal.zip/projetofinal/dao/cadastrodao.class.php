<?php
  //Para banco o ideal e mais indicado é requerir o arquivo de conexão - só irá executar as funções desta classe - se o arquivo abaixo for carregado.
  require '../persistence/conexaobanco.class.php';

  class CadastroDAO { //Classe para acessar os dados do objeto
    //Atributo de conexão:
    private $conexao = null;
    //Método construtor - para conexão:
    public function __construct(){
			$this->conexao = ConexaoBanco::getInstance();
		}
    //Método destruir a conexão com banco - a conexao está dentro do método construtor - então iremos destruir o método construir:
    public function __destruct(){

    }
    //Apartir daqui trabalhamos com o CRUD - uma função para cada item do CRUD - cadastrar (INSERT) - cadastrar , Read (SELECT) - visualizar ou pesquisar, Upadate (UPDATE) - atualizar, Delete (DELETE) - excluir
    //Função para cadatrar no banco:
    public function cadastrarCadastro($c){
      try{ //tratar erros - saber qual é - de onde vem
        //Nesta parte precisamos lembrar que o banco é CASE INSENSITIVE
        //Prepare é uma função que liga diretamente com query de banco - ali digitamos como o banco de dados:
        $stat = $this->conexao->prepare("INSERT INTO cadastro (idcadastro,email,senha,nome,site)VALUES(NULL,?,?,?,?)");
        //Abaixo vamos setar quais são os atributos ????
        //$c->nome - está pegando pelo método get mágico o nome da classe contato.class.php
        $stat->bindValue(1,$c->email);
				$stat->bindValue(2,$c->senha);
				$stat->bindValue(3,$c->nome);
				$stat->bindValue(4,$c->site);
        //mandamos executar a linha de comando do prepare:
        $stat->execute();
			}catch(PDOException $e){
			     echo "Erro ao cadastrar Cadastro! ".$e;
      }
    }

    //Função para pesquisar contatos - SELECT no banco:
    public function buscarCadastros(){
      try{
        //variável para executar a query de pesquisa:
        $stat = $this->conexao->query("SELECT * FROM cadastro");
        //criamos um array para guardar os dados vindo do objeto:
        $array = array();
        $array = $stat->fetchAll(PDO::FETCH_CLASS,'Cadastro');
        //!!!!!Arrumei a linha de cima tinha posto um E a mais no FETCH!!!!!
        $this->conexao = null;
        return $array;

      }catch(PDOException $e){
        echo "Erro ao buscar cadastros. ".$e;
      }
    }//fecha função buscar contatos

    //Função remover - excluir cruD - delete: requer do id para remoção sem erros:
     public function deletarCadastro($idcadastro){
       //Tratamos os erros com try catch
       try{
         //variável para preparar a exclusão:
         $stat = $this->conexao->prepare("DELETE FROM cadastro WHERE idcadastro=?");
         //Informamos o bindValue ?
         $stat->bindValue(1,$idcadastro);
         //executamos:
         $stat->execute();
         //finalizamos
         $this->conexao = null;
       }catch(PDOException $e){
         echo 'Erro ao deletar cadastro.';
       }//fecha catch
     }//fecha deletarContato

     //Funções para busca específica para alterar:
     //Método buscar - pesquisar por algo específico - utilizaremos para pesquisar contato afim de alterá-lo
     //receberá a condição de pesquisa QUERY
   	public function buscar($query){
   		try{
         //prepando a query de pesquisa
   			$stat = $this->conexao->query("SELECT * FROM cadastro ".$query);
   			$array = $stat->fetchAll(PDO::FETCH_CLASS,'Cadastro');

   			$this->conexao = null;
         //restornará o objeto encontrado em formado array:
   			return $array;

   		}catch(PDOException $e){
   			echo 'Erro ao buscar com filtro.';
   		}
   	}//fecha buscar

    //Função para alterar - crUd - UPDATE:
    //precisamos mandar o contato para alterar:
     public function alterarCadastro($c){
   		try{
         //preparando para executar o UPDATE:
   			$stat = $this->conexao->prepare('UPDATE cadastro SET email = ?, senha = ?, nome = ?, site = ? where idcadastro = ?');
         //definindo os bindValues = ???
         $stat->bindValue(1,$c->email);
         $stat->bindValue(2,$c->senha);
         $stat->bindValue(3,$c->nome);
         $stat->bindValue(4,$c->site);
         $stat->bindValue(5,$c->idcadastro);
         //executando:
   			return $stat->execute();
   			$this->conexao = null;

   		}catch(PDOException $e){
   			echo 'Erro ao alterar cadastro';
   		}//fecha try
   	}//fecha atualizar

  }//fecha classe
