<?php
//Para banco o ideal e mais indicado é requerir o arquivo de conexão - só irá executar as funções desta classe - se o arquivo abaixo for carregado.
require '../persistence/conexaobanco.class.php';

class UsuarioDAO
{ //DATA ACCESS OBJECT

  private $conexao = null;

  public function __construct()
  {
    $this->conexao = ConexaoBanco::getInstance();
  }

  public function __destruct()
  {
  }

  //cadastrarUsuario($u)
  //buscarUsuario()
  //filtrarUsuarios($filtro, $pesquisa)
  //deletarUsuario($id)

  public function verificarUsuario($u)
  {
    try {
      $stat = $this->conexao->prepare(
        "SELECT * FROM usuario WHERE login = ?
          AND senha = ? AND tipo = ?"
      );

      $stat->bindValue(1, $u->login, PDO::PARAM_STR);
      $stat->bindValue(2, $u->senha, PDO::PARAM_STR);
      $stat->bindValue(3, $u->tipo, PDO::PARAM_STR);

      $stat->execute();

      $usuario = $stat->fetchObject('Usuario');

      return $usuario;
    } catch (PDOException $e) {
      echo "Erro ao buscar usuarios! " . $e;
    } //fecha catch
  } //fecha buscarLivros
}//fecha classe
