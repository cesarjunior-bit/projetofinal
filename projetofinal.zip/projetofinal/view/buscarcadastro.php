<!--Aqui iremos iniciar a sessão - iniciando um objeto de sessão tbm-->
<?php
  session_start();
  ob_start();
?>

<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title> CADASTRO DE FOTÓGRAFO </title>
    <meta name="author" content="Júnior Souza">
    <meta name="description" content="Integrando FRON x BACK x BD">
    <meta name="keywords" content="PHP, HTML, BD, CSS, JS">
    <!-- Habilitando a leitura do tamanho do dispositivo -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="../img/icon.png">
    <!-- Bootstrap - download -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- CSS padrão -->
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <!-- Scripts do Bootstrap -->
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  </head>

  <body class="p-3 mb-2 bg-dark text-white">
    <main>
      <header id="topo" class="jumbotron text-center p-3 mb-2 bg-dark text-white" style="margin-bottom:0">
        <h1 class="jumbotron p-3 mb-2 bg-dark text-white">CADASTRO DE FOTÓGRAFO</h1>
      </header>

      <nav class="navbar navbar-inverse" style="margin-bottom: 0; border-radius: 0;">
        <ul class="nav justify-content-center">
          <li class="nav-item"><a class="nav-link active text-white" href="../index.html">Home</a></li>
          <!--O php abaixo apenas verificará se está na sessão privacidade usuário, e se é admin - se sim ele Apresentará um item Logout -->
          <?php
          if(isset($_SESSION['privateUser'])){
            include_once "../model/usuario.class.php";
            $u = unserialize($_SESSION['privateUser']);
            if($u->tipo == "adm"){
          ?>

          <li><a class="nav-link active text-white" href="../view/logar.php">Logout</a></li>
          <!--Se não - ele apresentará Botão área restrita -->
          <?php
            }
          }else{
            echo '<li><a href="logar.php">Área Restrita</a></li>';
          }
          ?>

        </ul>
      </nav>

      <section class="home container-fluid p-3 mb-2 bg-light text-dark" id="home">
        <!-- Para carregar os contatos - ele verifica primeiro se está logado como adm-->
        <?php
        if(isset($_SESSION['privateUser'])){
          include_once "../model/usuario.class.php";
          $u = unserialize($_SESSION['privateUser']);
          if($u->tipo == "adm"){
        ?>
        <h1 class="text-center"> Fotógrafos Cadastrados </h1>
        <?php
          include '../dao/cadastrodao.class.php';
          include '../model/cadastro.class.php';
          //Instanciamos a classe DAO para acessar função do CRUD:
          $cadastroDAO = new CadastroDAO();
          //Criamos uma variável para guardar resultado da pesquisa:
          $cadastros = $cadastroDAO->buscarcadastros();
          //Apresentando os dados em tabela:
         ?>
         <table class="table table-striped table-hover">
           <thead>
             <tr>
               <th>Código</th>
               <th>email</th>
               <th>senha</th>
               <th>nome</th>
               <th>site</th>
               <th>Editar/Excluir</th>
             </tr>
           </thead>
           <tbody>

             <?php
                foreach ($cadastros as $c) {
                  //vai se perder no código - precisamos colocar no model:
                  echo "<tr>";
                  echo "<td>".$c->idcadastro."</td>";
                  echo "<td>".$c->email."</td>";
                  echo "<td>".$c->senha."</td>";
                  echo "<td>".$c->nome."</td>";
                  echo "<td>".$c->site."</td>";
                  echo
                  "<td>
                    <a href='../controller/cadastro.controller.php?op=alterar&idcadastro=$c->idcadastro'>
                     <img src='../img/edita.png' alt='edita'></a>
                    &nbsp;&nbsp;
                    <a href='../controller/cadastro.controller.php?op=deletar&idcadastro=$c->idcadastro'>
                     <img src='../img/exclui.png' alt='Exclui'>
                     </a>
                  </td>";
                  echo "</tr>";
                }

              }//fim do if adm
              ?>
             </tbody>
           </table>
              <!--Caso não esteja logado - mostrar área restrita -->
              <?php
              }else{
                  echo "<h1 class='text-center'> Área Restrita </h1>";
                  echo "<h2 class='text-center'> Logue no sistema!</h2>";
              }
              ?>



    </section>
  </main>
 </body>
</html>
