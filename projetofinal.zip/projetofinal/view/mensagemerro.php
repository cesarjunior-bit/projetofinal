<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title> CADASTRO DE FOTÓGRAFO </title>
    <link rel="shortcut icon" href="../img/icone.png">
    <meta name="author" content="Júnior Souza">
    <meta name="description" content="Integrando FRON x BACK x BD">
    <meta name="keywords" content="PHP, HTML, BD, CSS, JS">
    <!-- Habilitando a leitura do tamanho do dispositivo -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap - download -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- CSS padrão -->
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <!-- Scripts do Bootstrap -->
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>

  </head>

  <body>
    <main>
      <header id="topo" class="jumbotron text-center" style="margin-bottom:0">
        <h1>CADASTRO DE FOTÓGRAFO</h1>
      </header>

      <nav class="navbar navbar-inverse" style="margin-bottom: 0; border-radius: 0;">
        <ul class="nav navbar-nav">
          <li><a href="../index.html">Home</a></li>
        </ul>
      </nav>

      <section class="home container-fluid" id="home">
          <h1 class="text-center"> ERROU!!! </h1>
          <?php
  				  //se houver uma sessão contatos:
            if(isset($_SESSION['cadastros'])){
  						//incluir se ainda não foi:
              include_once '../model/cadastro.class.php';
  						//cria uma variável para pegar o que veio pela sessão - objeto então array:
              $c = array();
  						//na variável atribuimos o que veio da sessã- para pegar utilizamos unserialize()
              $c = unserialize($_SESSION['cadastros']);
              echo $c;
            }
          ?>
      </section>

    </main>
  </body>
</html>
