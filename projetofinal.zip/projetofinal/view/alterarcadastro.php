<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">

<head>
  <meta charset="utf-8">
  <title> CADASTRO DE FOTÓGRAFO </title>
  <link rel="shortcut icon" href="../img/icon.png">
  <meta name="author" content="Júnior Souza">
  <meta name="description" content="Integrando FRON x BACK x BD">
  <meta name="keywords" content="PHP, HTML, BD, CSS, JS">
  <!-- Habilitando a leitura do tamanho do dispositivo -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap - download -->
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <!-- CSS padrão -->
  <link rel="stylesheet" type="text/css" href="../css/style.css">
  <!-- Scripts do Bootstrap -->
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>

<body class="p-3 mb-2 bg-dark text-white">
  <main>
    <header id="topo" class="jumbotron text-centerp-3 mb-2 bg-dark text-white" style="margin-bottom:0">
      <h1 class="jumbotron p-3 mb-2 bg-dark text-white text-center">CADASTRO DE FOTÓGRAFO</h1>
    </header>

    <nav class="navbar navbar-inverse" style="margin-bottom: 0; border-radius: 0;">
      <ul class="nav justify-content-center">
        <li class="nav-item"><a class="nav-link active text-white" href="../index.html">Home</a></li>
        <li class="nav-item"><a class="nav-link active text-white" href="../view/buscarcadastro.php">Visualizar Cadastros</a></li>
      </ul>
    </nav>

    <section class="contato" id="contato">
      <!-- Para alterar contato - ele verifica primeiro se está logado como adm-->
      <?php
      if (isset($_SESSION['privateUser'])) {
        include_once "../model/usuario.class.php";
        $u = unserialize($_SESSION['privateUser']);
        if ($u->tipo == "adm") {
      ?>

          <h2>Alterando Cadastro</h2>
          <br>
          <br>
          <?php
          //se houver uma sessão contatos:
          if (isset($_SESSION['dados_cadastro'])) {
            //incluir se ainda não foi:
            include_once '../model/cadastro.class.php';
            //cria uma variável para pegar o que veio pela sessão - objeto então array:
            //na variável atribuimos o que veio da sessã- para pegar utilizamos unserialize()
            $c = unserialize($_SESSION['dados_cadastro']);
          }
          ?>
          <!--Ação do form será para confirmaralteracao - criaremos ainda-->
          <form action="../controller/cadastro.controller.php?op=confirmaralteracao" method="post" name="form02" class="p-3 mb-2 bg-light text-dark">

            <div class="form-group">
              <label for="txtidcadastro">
                Código:
              </label>
              <!--Readonly envia o valor para o formulário e também não pode editar. Disabled você não pode editar nem obter o valor do input ao processar o Form. -->
              <input type="hidden" name="idcadastro" class="form-control" value="<?php echo $c[0]->idcadastro ?>" readonly="readonly" />
            </div>
            <div class="form-group">
              <label for="txtemail">
                email:
              </label>
              <input type="email" name="txtemail" class="form-control" value="<?php echo $c[0]->email ?>" /> </br>
            </div>
            <div class="form-group">
              <label for="txtsenha">
                senha:
              </label>
              <input type="password" name="txtsenha" value="<?php echo $c[0]->senha ?>" class="form-control" /> </br>
            </div>
            <div class="form-group">
              <label for="txtnome">
                nome:
              </label>
              <input type="text" name="nome" value="<?php echo $c[0]->nome ?>" class="form-control" /> </br>
            </div>
            <div class="form-group">
              <label for="txtsite">
                site:
              </label>
              <input type="site" name="site" value="<?php echo $c[0]->site ?>" class="form-control" /> </br>
            </div>
            <!--Aqui encerramos a sessão -->
            <?php
            unset($_SESSION['dados_cadastro']);
            ?>
            <a href="../view/buscarcadastros.php?op=confirmaralteracao"><input type="submit" name="cancela" value="Cancelar" class="btn btn-dark"></a>
            <input type="submit" name="altera" value="Alterar" class="btn btn-dark">
          </form>
      <?php
        } //fim do if adm
        //se não estiver logado
      } else {
        echo "<h1 class='text-center'> Área Restrita </h1>";
        echo "<h2 class='text-center'> Logue no sistema!</h2>";
      }
      ?>
      </aside>

    </section>


    <footer class="navbar-fixed-bottom rodape">
      <span>Todos direitos &copy; reservados a César Júnior</span>
    </footer>

  </main>

</body>

</html>