<?php
  session_start();
  ob_start();
?>
<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title> CADASTRO DE FOTÓGRAFO </title>
    <link rel="shortcut icon" href="../img/icon.png">
    <meta name="author" content="Júnior Souza">
    <meta name="description" content="Integrando FRON x BACK x BD">
    <meta name="keywords" content="PHP, HTML, BD, CSS, JS">
    <!-- Habilitando a leitura do tamanho do dispositivo -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap - download -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- CSS padrão -->
    <link rel="stylesheet" type="../text/css" href="css/style.css">
    <!-- Scripts do Bootstrap -->
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  </head>

  <body class="p-3 mb-2 bg-dark text-white">
    <main>
      <header id="topo" class="jumbotron text-center p-3 mb-2 bg-dark text-white" style="margin-bottom:0">
        <h1 class="jumbotron p-3 mb-2 bg-dark text-white">CADASTRO DE FOTÓGRAFO</h1>
      </header>

      <nav class="navbar navbar-inverse" style="margin-bottom: 0; border-radius: 0;">
      <ul class="nav justify-content-center">
          <li class="nav-item"><a class="nav-link active text-white" href="../index.html">Home</a></li>
          <li class="nav-item"><a class="nav-link active text-white" href="logar.php">Área Restrita</a></li>

          <?php
          if(isset($_SESSION['privateUser'])){
            include_once "../model/usuario.class.php";
            $u = unserialize($_SESSION['privateUser']);
            if($u->tipo == "adm"){
          ?>
          <li class="nav-item"><a class="nav-link active text-white" href="../view/buscarcadastro.php">Visualizar Cadastros</a></li>
          <?php
            }
          }
          ?>
        </ul>
      </nav>


      <section class="home container-fluid" id="home">
            <h1 class="text-center"> Logar no Sistema </h1>

            <?php
            if(isset($_SESSION['privateUser'])){
              include_once "../model/usuario.class.php";
              $u = unserialize($_SESSION['privateUser']);
              echo "<h2>Olá {$u->login}, seja bem vindo!</h2>";
            ?>

            <form name="deslogar" method="post" action="">
              <div class="form-group">
                <input type="submit" name="deslogar" value="Sair" class="btn btn-dark">
              </div>
            </form>
            <?php
            if(isset($_POST['deslogar'])){
              unset($_SESSION['privateUser']);
              header("location:logar.php");
            }
            ?>

            <?php
              }else{
            ?>
            <form name="login" method="post" action="" class="p-3 mb-2 bg-light text-dark">
              <div class="form-group">
                <input type="text" name="txtlogin" placeholder="Login" class="form-control">
              </div>
              <div class="form-group">
                <input type="password" name="txtsenha" placeholder="Digite sua senha" class="form-control">
              </div>
              <div class="form-group">
                <select name="seltipo" class="form-control">
                  <option value="adm">Adm</option>
                  <option value="visitante">Visitante</option>
                </select>
              </div>
              <div class="form-group">
                <input type="submit" name="entrar" value="Entrar" class="btn btn-dark">
              </div>
            </form>
            <?php
              }
            ?>

            <!--Esta parte toda pode por no controller!!! -->
            <?php
            if(isset($_POST['entrar'])){
              include '../model/usuario.class.php';
              include '../dao/usuariodao.class.php';
              //include 'util/seguranca.class.php';

              $u = new Usuario();
              $u->login = $_POST['txtlogin'];
              $u->senha = MD5($_POST['txtsenha']);
              $u->tipo = $_POST['seltipo'];

              //echo $u;

              $uDAO = new UsuarioDAO();
              $usuario = $uDAO->verificarUsuario($u);

              if($usuario == null){
                echo "<h2>Usuário/senha/tipo inválido(s)!</h2>";
              }else{
                echo "<h2>logado</h2>";
                $_SESSION['privateUser'] = serialize($usuario);
                header("location:logar.php");
              }
            }
            ?>
      </section>

    </main>
  </body>
</html>
